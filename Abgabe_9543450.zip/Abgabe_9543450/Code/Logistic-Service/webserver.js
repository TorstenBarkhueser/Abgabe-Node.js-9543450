/**
 * Server, der den Logistic-Service für die Nutzung der Website bereitstellt
 * @type {createApplication}
 */
const express = require('express');
const shelf = require('./script/shelf.js');
const product = require('./script/product.js');
const storageJson = require('./script/storageJson.js');
const app = express();
app.use(express.json());
/**
 * REST-Schnittstelle, auf die die Website zugreifen kann
 */
app.post('/addShelf', (req, res) => {
    let id = req.body.id;
    let capacity = req.body.capacity;
    console.log("POST-Request at /addShelf with parameters id : " + id + ", capacity : " + capacity);
    res.status(shelf.addShelf(id, capacity));
    res.end();
});
app.post('/removeShelf', (req, res) => {
    let id = req.body.id;
    console.log("POST-Request at /removeShelf with parameters id : " + id );
    res.status(shelf.removeShelf(id));
    res.end();
});
app.post('/clearStorage', (req, res) => {
    console.log("POST-Request at /clearStorage");
    res.status(shelf.clearStorage());
    res.end();
});
app.post('/addProduct', (req, res) => {
    let id = req.body.id;
    let shelfid = req.body.shelfid;
    let count = req.body['count'];
    console.log("POST-Request at /addProduct with parameters id : " + id + ", shelfId : " + shelfid + ", count : " + count);
    res.status(product.addProduct(id, shelfid, count));
    res.end();
});
app.post('/removeProduct', (req, res) => {
    let id = req.body.id;
    let shelfid = req.body.shelfid;
    console.log("POST-Request at /removeProduct with parameters id : " + id + ", shelfId : " + shelfid);
    res.status(product.removeProduct(id, shelfid));
    res.end();
});
app.get('/getStorage', (req, res) => {
    res.end(storageJson.getStorageJson());
});
/**
 * Der Service wird auf dem Port 8091 bereitgestellt
 */
app.listen(8091, () => console.log('Listening on http://127.0.0.1:8091/'));
