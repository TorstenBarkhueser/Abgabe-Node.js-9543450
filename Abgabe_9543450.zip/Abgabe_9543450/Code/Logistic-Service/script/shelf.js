const filepath = './script/data/storage.xml';
const fs = require('fs');
const xml2js = require('xml2js');
const parser = new xml2js.Parser({attrkey: "ATTR"});

/**
 * Funktionen, die von den REST-Schnittstellen aufgerufen werden um die Regale zu bearbeiten
 */

module.exports  = {
    addShelf: function (id, capacity) {
        var storage = readStorageFile();
        var shelf = searchShelf(id, storage['root']['storage'][0]['shelf']);

        if (shelf != null){
            console.log("Error Shelf: " + id + " already exists");
            return 304;
        }
        else {
            storage['root']['storage'][0]['shelf'].push({"id":[id],
                "capacity":[capacity], "products":{"product":{}}});
            var builder = new xml2js.Builder({pretty: true});
            var newFile = builder.buildObject(storage);
            fs.writeFile(filepath, newFile, function (err, file) {
                if (err) throw err;
                console.log("Shelf successfully added!");
            });
            return 200;
        }
    },

    removeShelf: function (id) {
        var storage = readStorageFile();
        var shelf = searchShelf(id, storage['root']['storage'][0]['shelf']);
        if (shelf == null){
            console.log("Error Shelf: " + id + " does not exist");
            return 404
        }
        else {
            delete storage['root']['storage'][0]['shelf'][shelf];
            var builder = new xml2js.Builder({pretty: true});
            var newFile = builder.buildObject(storage);
            fs.writeFile(filepath, newFile, function (err, file) {
                if (err) throw err;
                console.log("Shelf successfully removed!");
            });
            return 200;
        }
    },

    clearStorage: function () {
        fs.writeFile(filepath, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
            "<root>\n" +
            "  <storage>\n" +
            "    <shelf/>\n" +
            "  </storage>\n" +
            "</root>"
            , function (err, file) {
                if (err) throw err;
                console.log("Storage cleared!");
            });
        return 200;
    }
};

function searchShelf(id, shelves) {
    for (var i = 0; i < shelves.length; i++) {
        if (shelves[i]['id'] == id) {
            return i;
        }
    }
    return null;
}

/**
 * Lesen der storage.xml als JSON
 * @returns {string}
 */

function readStorageFile() {
    var storage = fs.readFileSync(filepath, 'utf8');
    parser.parseString(storage, function (error, result) {
        if (error == null) {
            storage = result;
        }
        else {
            console.log(error);
        }
    });
    return storage;
}

