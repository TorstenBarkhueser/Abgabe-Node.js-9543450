const filepath = './script/data/storage.xml';
const fs = require('fs');
const xml2js = require('xml2js');
const parser = new xml2js.Parser({attrkey: "ATTR"});

/**
 * Lesen der storage.xml und Parsen der Daten in einen String
 * @type {{getStorageJson: (function(): string)}}
 */

module.exports = {
    getStorageJson: function () {
        var storage = fs.readFileSync(filepath, 'utf8');
        parser.parseString(storage, function (error, result) {
            if (error == null) {
                storage = result;
            }
            else {
                console.log(error);
            }
        });
        return JSON.stringify(storage);
    }
};
