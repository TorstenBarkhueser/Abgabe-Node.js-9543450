const filepath = './script/data/storage.xml';
const fs = require('fs');
const xml2js = require('xml2js');
const parser = new xml2js.Parser({attrkey: "ATTR"});

/**
 * Funktionen, die von den REST-Schnittstellen aufgerufen werden um die Produkte zu bearbeiten
 */

module.exports  = {
    addProduct: function (id, shelfid, count) {
        var storage = readStorageFile();
        var shelf = searchShelf(shelfid, storage['root']['storage'][0]['shelf']);

        if (shelf == null){
            console.log("Error Shelf: " + id + " does not exists");
            return 304;
        }
        else {
            let capacity = storage['root']['storage'][0]['shelf'][shelf]['capacity'][0].valueOf();
            if ((capacity - count) < 0) {
                console.log("Product does not fit on the shelf.");
                return 409;
            }

            storage['root']['storage'][0]['shelf'][shelf]['capacity'] = (capacity - count).toString();
            storage['root']['storage'][0]['shelf'][shelf]['products'][0]['product'].push({"id":[id],"count":[count]});
            var builder = new xml2js.Builder({pretty: true});
            var newFile = builder.buildObject(storage);
            fs.writeFile(filepath, newFile, function (err, file) {
                if (err) throw err;
                console.log("Product successfully added!");
            });
            return 201;
        }
    },

    removeProduct: function (id, shelfid) {
        var storage = readStorageFile();
        var shelf = searchShelf(shelfid, storage['root']['storage'][0]['shelf']);
        if (shelf == null){
            console.log("Error Shelf: " + id + " does not exist");
            return 304;
        }
        else {
            let product = searchProduct(id, storage['root']['storage'][0]['shelf'][shelf]['products'][0]['product']);
            if (product == null) {
                console.log("Error Product: " + id + " does not exist");
                return 304;
            }
            let capacity = storage['root']['storage'][0]['shelf'][shelf]['capacity'][0].valueOf();
            let count = storage['root']['storage'][0]['shelf'][shelf]['products'][0]['product'][product]['count'].valueOf();
            storage['root']['storage'][0]['shelf'][shelf]['capacity'][0] = (parseInt(capacity) + parseInt(count)).toString();

            delete storage['root']['storage'][0]['shelf'][shelf]['products'][0]['product'][product];
            var builder = new xml2js.Builder({pretty: true});
            var newFile = builder.buildObject(storage);
            fs.writeFile(filepath, newFile, function (err, file) {
                if (err) throw err;
                console.log("Product successfully added!");
            });
        }
        return 201;
    },
};

function searchShelf(id, shelves) {
    for (var i = 0; i < shelves.length; i++) {
        if (shelves[i]['id'] == id) {
            return i;
        }
    }
    return null;
}

function searchProduct(id, shelf) {
    for (var i = 0; i < shelf.length; i++) {
        if (shelf[i]['id'] == id) {
            return i;
        }
    }
    return null;
}

function readStorageFile() {
    var storage = fs.readFileSync(filepath, 'utf8');
    parser.parseString(storage, function (error, result) {
        if (error == null) {
            storage = result;
        }
        else {
            console.log(error);
        }
    });
    return storage;
}

