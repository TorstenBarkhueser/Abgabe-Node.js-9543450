const url = 'http://127.0.0.1:8091/';

/**
 * Schnittstellen, die POST-Requests über den Proxy auf dem Server an den Logistic-Service senden.
 * Die Parameter werden durch die Eingaben auf der Website festgelegt.
 * @param id
 * @param capacity
 */

function addShelf(id, capacity) {
    if (capacity.valueOf() <= 0) {
        alert("Bitte geben sie eine Größe ein, die größer als Null ist.")
    }
    else {
        storagePostRequest("addShelf", ' { \"id\" : \"' + id
            + '\", \"capacity\" : \"' + capacity.toString() + '\" }');
        loadStorage();
    }
}

function removeShelf(id) {
    storagePostRequest("removeShelf", ' { \"id\" : \"' + id + '\" }')
    loadStorage();
}

function addProduct(id, shelfid, count) {
    if (count.valueOf() <= 0) {
        alert("Bitte geben sie eine Menge ein, die größer als Null ist.")
    }
    else {
        storagePostRequest("addProduct", ' { \"id\" : \"' + id + '\", \"shelfid\" : \"' + shelfid + '\", \"count\" : \"' + count.toString() + '\" }')
        loadStorage();
    }
}

function removeProduct(id, shelfid) {
    storagePostRequest("removeProduct", ' { \"id\" : \"' + id + '\", \"shelfid\" : \"' + shelfid + '\" }')
    loadStorage();
}

function clearStorage() {
    storagePostRequest("clearStorage", '{}')
    loadStorage();
}

/**
 * Ausgelagerte POST-Request über den Proxy auf dem Server
 * @param path
 * @param form
 */

function storagePostRequest(path, form) {
    fetch("/postFile",
        {
            method: "POST",
            body: JSON.stringify({ url: url + path, form: form}),
            headers : {'Content-Type': 'application/json'}
        })
        .then(function(res){
            console.log("res : " + res);
            return res.text();
        })
        .then(function(data) {
            console.log("data : " + data);
        });
}

/**
 * Laden der Daten per GET-Request über den Proxy auf dem Server
 */

function loadStorage() {
    fetch("/getFile",
        {
            method: "POST",
            body: JSON.stringify({ url: 'http://127.0.0.1:8091/getStorage'}),
            headers : {'Content-Type': 'application/json'}
        })
        .then(function(res){
            console.log("res : " + JSON.stringify(res));
            return res.text();
        })
        .then(function(data) {
            console.log("data : " + JSON.stringify(data));
            refreshStorageHtml(data);
        });
}

/**
 * Erstellung der HTML-Tabelle mit den Daten von der GET-Request
 * @param content
 */

function refreshStorageHtml(content)
{
    console.log("RAW : " + content);
    console.log("JSON " + JSON.parse(content));
    var json = JSON.parse(content);
    var shelves = json['root']['storage'][0]['shelf'];

    var storageDiv = document.getElementById("storage_div");
    var storageTable = document.createElement("table");


    var headerrow = document.createElement("tr");
    var currentElement = document.createElement("th");
    currentElement.appendChild(document.createTextNode('Regal-ID'));
    headerrow.appendChild(currentElement);
    currentElement = document.createElement("th");
    currentElement.appendChild(document.createTextNode('Freier Platz'));
    headerrow.appendChild(currentElement);
    currentElement = document.createElement("th");
    currentElement.appendChild(document.createTextNode('Produkte'));
    headerrow.appendChild(currentElement);
    storageTable.appendChild(headerrow);

    for (var i = 1; i < shelves.length; i++) {
        var shelfrow = document.createElement("tr");
        currentElement = document.createElement("td");
        currentElement.appendChild(document.createTextNode(shelves[i]['id']));
        shelfrow.appendChild(currentElement);
        currentElement = document.createElement("td");
        currentElement.appendChild(document.createTextNode(shelves[i]['capacity']));
        shelfrow.appendChild(currentElement);

        var productTable = document.createElement('table')
        var productHeaderrow = document.createElement("tr");
        currentElement = document.createElement("th");
        currentElement.appendChild(document.createTextNode('Produkt-ID'));
        productHeaderrow.appendChild(currentElement);
        currentElement = document.createElement("th");
        currentElement.appendChild(document.createTextNode('Anzahl'));
        productHeaderrow.appendChild(currentElement);
        productTable.appendChild(productHeaderrow);

        var products = shelves[i]['products'][0]['product'];
        for (var k = 1; k < products.length; k++) {
            var productRow = document.createElement('tr');
            currentElement = document.createElement("td");
            currentElement.appendChild(document.createTextNode(products[k]['id']));
            productRow.appendChild(currentElement);
            currentElement = document.createElement("td");
            currentElement.appendChild(document.createTextNode(products[k]['count']));
            productRow.appendChild(currentElement);
            productTable.appendChild(productRow);
        }
        currentElement = document.createElement("td");
        currentElement.appendChild(productTable);
        shelfrow.appendChild(currentElement);
        storageTable.appendChild(shelfrow);
    }
    storageTable.id = 'storage_table';
    var oldtable = document.getElementById('storage_table');
    storageDiv.replaceChild(storageTable, oldtable);
}

