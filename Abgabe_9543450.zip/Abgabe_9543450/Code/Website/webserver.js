/**
 * Server, der die Website bereitstellt
 * @type {createApplication}
 */
const express = require('express');
const request = require('request');
const app = express();
app.use(express.json());
/**
 * Proxy für GET-Requests, die auf der Website ausgelöst werden
 */
app.post('/getFile', (req, res) => {
    let url = req.body.url;
    request.get(url, (error, resp, body) => {
        res.send(body);
    });
});
/**
 * Proxy für POST-Requests, die auf der Website ausgelöst werden
 */
app.post('/postFile', (req, res) => {
   let url = req.body.url;
   let form = req.body.form;
   console.log("1 : " + url + form);
   request.post({url:url, json:JSON.parse(form)}, function (err, res, body) {
       console.log("2 : err: " + err + " res: " + JSON.stringify(res) + " body: " + JSON.stringify(body));
   });
   res.end();
});
/**
 * Bereitstellung der index.html auf dem Port 8090
 */
app.use(express.static('.'));
app.listen(8090, () => console.log('Listening on http://127.0.0.1:8090/'));
